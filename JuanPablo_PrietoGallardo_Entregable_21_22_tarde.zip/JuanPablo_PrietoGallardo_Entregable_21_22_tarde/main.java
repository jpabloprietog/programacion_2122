package JuanPablo_PrietoGallardo_Entregable_21_22_tarde;

public class main {
    public static void main(String[] args) {

        //Mano de Obra
        ManoDeObra cuadrillauno = new ManoDeObra(nombreEmpresa "");

        //Mostrar tipo de instancias
        Vivienda.mostrarEstanciasPosibles();

        //Construccion de la vivienda
        Vivienda casaUno = new Vivienda("Calle Clavel 4", "80", numEstancias "6");

        //Creación de la obra
    }
}

//Nombre de empresa
//Descripción del trabajo realizado
//Horas realizadas
//Cantidad de obreros implicados

package JuanPablo_PrietoGallardo_Entregable_21_22_tarde;

public class ManoDeObra {

    //Atributos de la clase Mano de Obra.
    private String NombreEmpresa;
    private String Descripcion;
    private Integer HorasRealizadas;
    private Integer CantidadObreros;

    //construcción de los metodos "getter" y "setter".
    public String getNombreEmpresa() {
        return NombreEmpresa;
    }
    public void setNombreEmpresa(String nombreEmpresa) {
        NombreEmpresa = nombreEmpresa;
    }
    public String getDescripcion() {
        return Descripcion;
    }
    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }
    public Integer getHorasRealizadas() {
        return HorasRealizadas;
    }
    public void setHorasRealizadas(Integer horasRealizadas) {
        HorasRealizadas = horasRealizadas;
    }
    public Integer getCantidadObreros() {
        return CantidadObreros;
    }
    public void setCantidadObreros(Integer cantidadObreros) {
        CantidadObreros = cantidadObreros;
    }

    //Constructor
    public ManoDeObra(String nombreEmpresa, String descripcion, Integer horasRealizadas, Integer cantidadObreros) {
        this.NombreEmpresa = nombreEmpresa;
        this.Descripcion = descripcion;
        this.HorasRealizadas = horasRealizadas;
        this.CantidadObreros = cantidadObreros;
    }

    //Mostrar informacion sobre la Mano de Obra
        public void mostrarInformacion() {
            System.out.println("Nombre de la empresa " + this.NombreEmpresa);
            System.out.println("Descripcion " + this.Descripcion);
            System.out.println("Horas realizadas " + this.HorasRealizadas);
            System.out.println("Cantidad de Obreros " + this.CantidadObreros);
        }
    }

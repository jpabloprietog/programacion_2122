//En la Obra, podremos ir añadiendo los materiales según se vayan necesitando,
//así que tendremos un método en la clase que recibirá el material en cuestión y lo añadirá a la lista de materiales de la Obra.
//Igualmente se necesitará devolver materiales (eliminarlos de la obra).
//Así que tendremos que desarrollar un método que recibe la posición del material que se quiere eliminar y lo elimine.
//Todos los atributos de las clases deberán tener los Setter y Getter correspondientes (aunque no se utilicen),
//y todos los atributos tendrán que ser privados salvo que sea absolutamente necesario tener uno público.


package JuanPablo_PrietoGallardo_Entregable_21_22_tarde;

import java.util.Calendar;

public class Obra {

        //Atributos de la clase obra
        private Vivienda obraVivienda;
        private Material[] listaMateriales;
        private ManoDeObra albañil;
        private Vivienda.estanciasenum estanciaObra;
        private Calendar fechaObra;

        //Metodo para mostrar fecha.
        public void métodoFecha(){
            String dia, mes, annio;
            dia = Integer.toString(fechaObra.get(Calendar.DATE));
            mes = Integer.toString(fechaObra.get(Calendar.MONTH));
            annio = Integer.toString(fechaObra.get(Calendar.YEAR));

            System.out.println("Fecha" + dia + "/" + mes + "/" + annio);
        }


        //Creación Método Getter y Setter
    public Vivienda getObraVivienda() {
        return obraVivienda;
    }
    public void setObraVivienda(Vivienda obraVivienda) {
        this.obraVivienda = obraVivienda;
    }
    public Material[] getListaMateriales() {
        return listaMateriales;
    }
    public void setListaMateriales(Material[] listaMateriales) {
        this.listaMateriales = listaMateriales;
    }
    public ManoDeObra getAlbañil() {
        return albañil;
    }
    public void setAlbañil(ManoDeObra albañil) {
        this.albañil = albañil;
    }
    public Vivienda.estanciasenum getEstanciaObra() {
        return estanciaObra;
    }
    public void setEstanciaObra(Vivienda.estanciasenum estanciaObra) {
        this.estanciaObra = estanciaObra;
    }
    public Calendar getFechaObra() {
        return fechaObra;
    }
    public void setFechaObra(Calendar fechaObra) {
        this.fechaObra = fechaObra;
    }
    //Creación del constructor obra
    public Obra(Vivienda obraVivienda, Material[] listaMateriales, ManoDeObra albañil, Vivienda.estanciasenum estanciaObra, Calendar fechaObra) {
        this.obraVivienda = obraVivienda;
        this.listaMateriales = listaMateriales;
        this.albañil = albañil;
        this.estanciaObra = estanciaObra;
        this.fechaObra = Calendar.getInstance();
        this.listaMateriales = new Material[0];
    }

    //Mostrar informacion de la obra
    public void mostrarInformacion (){
        System.out.println("vivienda " + this.obraVivienda);
        System.out.println("Materiales " + this.listaMateriales);
        }
    }

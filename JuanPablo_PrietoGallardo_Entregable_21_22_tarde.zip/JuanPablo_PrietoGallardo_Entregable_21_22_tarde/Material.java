//Para ello, necesitaremos conocer la cantidad de Material necesario (materiales, en términos generales).
//Para cada material, necesitamos conocer:
//La descripción del material
//El proveedor del mismo
//Las unidades necesarias
//El precio por unidad
//IVA aplicable
//El precio tendrá que estar entre 0 y 100000. Las unidades, entre 1 y 1000.
//
//El IVA será un atributo común a todos los materiales, y si el gobierno de turno decide cambiarlo, se aplicará a todos los materiales.
//Por tanto, deberá implementarse un método de clase para obtener el IVA y otro para cambiarlo.
//
//Para tener un material, es necesario conocer todos los datos del mismo, pero hay veces que el proveedor no lo conocemos,
//así que tendremos que contemplar esa posibilidad.

package JuanPablo_PrietoGallardo_Entregable_21_22_tarde;

public class Material {

    //Atributos de la clase Material.
    private String descripcionMat;
    private String proveedorMat;
    private Integer unidades;
    private Double PrecioXUnidad;
    private static Double IVA = 0.21;

    //Construcción de los métodos "Getter" y "Setter" (generate)

    public String getDescripcionMat() {
        return descripcionMat;
    }

    public void setDescripcionMat(String descripcionMat) {
        this.descripcionMat = descripcionMat;
    }

    public String getProveedorMat() {
        return proveedorMat;
    }

    public void setProveedorMat(String proveedorMat) {
        this.proveedorMat = proveedorMat;
    }

    public Integer getUnidades() {
        return unidades;
    }

    //Las unidades tienen que estar comprendidas entre 1 y 1000.
    public void setUnidades(Integer unidades) {
        if (unidades >= 1 && unidades <= 1000) {
            this.unidades = unidades;
        } else {
            System.out.println("Las unidades tienen que ser entre 1 y 1000");
        }
    }

    public Double getPrecioXUnidad() {
        return PrecioXUnidad;
    }

    //El precio de la unidad tiene que estar comprendido ente 1 y 10000
    public void setPrecioXUnidad(Double precioXUnidad) {
        if (precioXUnidad >= 0 && precioXUnidad <= 100000) {
            this.PrecioXUnidad = precioXUnidad;
        } else {
            System.out.println("El precio de la unidad tiene que ser entre 0 y 10000");
        }
    }

    public static Double getIVA() {
        return IVA;
    }

    public static void setIVA(Double IVA) {
        Material.IVA = IVA;
    }

    //Constructor que recoja todos los datos.
    public Material(String descripcionMat, String proveedorMat, Integer unidades, Double precioXUnidad) {
        this.descripcionMat = descripcionMat;
        this.proveedorMat = proveedorMat;
        this.unidades = unidades;
        this.PrecioXUnidad = precioXUnidad;
    }

    //Constructor que recoja todos los datos sin proveedor.
    public Material(String descripcionMat, Integer unidades, Double precioXUnidad) {
        this.descripcionMat = descripcionMat;
        this.unidades = unidades;
        this.PrecioXUnidad = precioXUnidad;
        this.proveedorMat = "Desconocido";
    }

    public void mostrarInformacion() {
        System.out.println("Material " + this.descripcionMat);
        System.out.println("proveedor " + this.proveedorMat);
        System.out.println("unidades " + this.unidades);
        System.out.println("Precio x Unidad " + this.PrecioXUnidad);
        System.out.println("PVP con IVA " + ((this.unidades * this.PrecioXUnidad) * IVA));
        System.out.println("PVP sin IVA " + this.unidades * this.PrecioXUnidad);


    }
}
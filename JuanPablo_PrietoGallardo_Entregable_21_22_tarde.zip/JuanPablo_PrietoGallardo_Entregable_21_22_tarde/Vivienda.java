//Dirección de la vivienda
//Metros cuadrados de la misma
//Lista de Estancias de las que consta la vivienda.
//La estancias son los siguientes valores concretos posibles: SALÓN, COCINA, BAÑO, DORMITORIO, TERRAZA, VESTÍBULO, COMEDOR, BALCÓN.
//Pueden estar repetidos, por ejemplo, que tenga 2 BAÑOS o 3 DORMITORIOS.


package JuanPablo_PrietoGallardo_Entregable_21_22_tarde;

import java.util.Arrays;

public class Vivienda {

    public enum estanciasenum {
        SALÓN,
        COCINA,
        BAÑO,
        DORMITORIO,
        TERRAZA,
        VESTÍBULO,
        COMEDOR,
        BALCÓN
    }

    //Atributos de la clase Vivienda
    private String direccion;
    private Integer metroCuadrado;
    private estanciasenum = new listadoEstancias;
    private int IndiceEstancias;


    //Creación de los métodos getter y setter.
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Integer getMetroCuadrado() {
        return metroCuadrado;
    }

    public void setMetroCuadrado(Integer metroCuadrado) {
        this.metroCuadrado = metroCuadrado;
    }

    public estanciasenum[] getListadoEstancias() {
        return listadoEstancias;
    }

    public void setListadoEstancias(estanciasenum[] listadoEstancias) {
        this.listadoEstancias = listadoEstancias;
    }

    public int getIndiceEstancias() {
        return IndiceEstancias;
    }

    public void setIndiceEstancias(int indiceEstancias) {
        IndiceEstancias = indiceEstancias;
    }

    public Vivienda(String direccion, Integer metroCuadrado, estanciasenum[] listadoEstancias, int indiceEstancias) {
        this.direccion = direccion;
        this.metroCuadrado = metroCuadrado;
        this.listadoEstancias = new estanciasenum();
        this.IndiceEstancias = 0;
    }

    //Creación de un métodos para añadir una habitación
    public void addEstancia(estanciasenum estancias) {
        if (IndiceEstancias < listadoEstancias.length) {
            listadoEstancias = Arrays.copyOf(listadoEstancias, listadoEstancias.length + 1);
        }
        listadoEstancias[IndiceEstancias++] = estancias;
        IndiceEstancias++;
    }

    //Metodo para quitar una Estancia
    public void EliminarEstancia(int Indice) {
        if (Indice < IndiceEstancias && Indice >= 0) {
            int[] aux = new int[IndiceEstancias - 1];
            for (int i = 0; i < Indice; i++) {
                aux[i] = IndiceEstancias[i];
            }
            for (int i = 0; i < Indice; i++) {
                aux[i] = IndiceEstancias[i + 1];
            }
        } else {
            System.out.println("Warning, esa estancia no está disponible");
        }

        //Creación de un metodo que muestre todas las estancias posibles
        public static void mostrarEstancias() {
            System.out.println("Posibles Estancias ");
            for (estanciasenum estancia : estanciasenum.values()) {
                System.out.println(estancia + " ");
            }
        }
    }

    //Creacion del método para mostrar información
    public void mostrarInformacion() {
        System.out.println("Direccion" + this.direccion);
        System.out.println("Metros cuadrados " + this.metroCuadrado);
        System.out.println("Estancias " + this.listadoEstancias);
        for (int i = 0; i < IndiceEstancias; i++) {
            System.out.println(IndiceEstancias[i]);
        }
    }
}


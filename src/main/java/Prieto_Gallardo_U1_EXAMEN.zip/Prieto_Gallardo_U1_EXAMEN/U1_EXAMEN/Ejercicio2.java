package U1_EXAMEN;

import java.util.Scanner;

public class Ejercicio2 {

    public static void main(String[] args) {

        long num;
        long invertido = 0;
        long cociente =0;
        long resto = 0;


        System.out.println("Introduce un número");
        Scanner scanner = new Scanner(System.in);
        num = scanner.nextLong();

        while (cociente != 0) {
                resto = cociente % 10;
                cociente = cociente / 10;
            }
        }
    }

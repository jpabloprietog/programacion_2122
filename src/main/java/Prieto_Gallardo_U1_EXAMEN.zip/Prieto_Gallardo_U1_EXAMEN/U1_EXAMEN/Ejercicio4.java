package U1_EXAMEN;

import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int ABS = 1;
        int PLA = 2;
        int Madera = 3;
        int Flexible = 4;
        int peso = 0;
        boolean procesado = true;

        System.out.println("Bienvenido a Carbonita Volando");
        System.out.println("Introduzca el peso de la figura en gramos");
        peso = scanner.nextInt();
        System.out.println("Introduzca el peso de la figura en gramos");
        int tipo_mat = scanner.nextInt();
        System.out.println("Introduzca el tipo de material (1=ABS, 2=PLA, 3=Madera 4=Flexible");

        System.out.println("¿Quiere Procesado?");
        System.out.println("¿pertenece a Enjuto3D Premium? (1=si, 2=no");

        int tipo_material;
        tipo_material = scanner.nextInt();

        int coste_total = tipo_material * peso;

        if (tipo_material == ABS)
            System.out.println("coste_total" + ABS * peso);
        if (tipo_material == PLA)
            System.out.println("coste_total" + PLA * peso);
        if(tipo_material == Madera)
            System.out.println("coste_total" + Madera * peso);
        if (tipo_material == Flexible)
            System.out.println("coste_total" + Flexible * peso);

        System.out.println("El coste total de la pieza es:" + tipo_mat * coste_total);
    }
}





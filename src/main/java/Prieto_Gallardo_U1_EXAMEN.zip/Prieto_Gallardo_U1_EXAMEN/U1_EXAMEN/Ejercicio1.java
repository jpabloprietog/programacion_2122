package U1_EXAMEN;

import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String[] args) {

        int altura;

        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("Introduce un numero");
            altura = scanner.nextInt();

        } while
        (altura > 3 && altura % 2 == 0);

        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < altura; j++) {
                if (j == (altura) - 1 - i
                        || j == altura - i + 1
                        || i == altura - altura / 2
                        && j >= altura - i - 1
                        && j <= altura - i + 1)

                    System.out.print("*");
                else {
                    System.out.print(" ");
                }

                for (i = 0; i < 2; i++) {
                    System.out.print("*");
                    for (j = 0; j < altura; j++) {
                        if (i == 0 && j < altura
                                || (i == altura / 2) && j < altura - i && j < altura - 1
                                || (j == 0)
                                || (j == altura - 1 && i > 0 && i < altura / 2))
                            System.out.print("*");
                        else {
                            System.out.print(" ");
                        }
                        System.out.println();

                        scanner.close();
                    }
                }
            }
        }
    }
}

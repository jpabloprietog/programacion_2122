package u1_entregable;

import java.util.Scanner;

public class Ej3 {

    public static void main(String[] args) {

        int teclado;
        int preciohamburguesabasica = 3;
        int preciohamburguesagourmet = 5;
        int preciototal;
        int descuento;
        int pago;

        Scanner scanner = Scanner(System.in);

        System.out.println("Pedidos Pitanza Feliz");
        teclado = scanner.nextInt();

        System.out.println("Número de hamburguesas básicas:");
        teclado = scanner.nextInt();

        System.out.println("Dia de la semana");
        String diasemana = scanner.nextLine();

        System.out.println("¿Pertenece al club Fanegas?");
        char clubfanegas = scanner.next().charAt(0);

        if (diasemana.equals()){
    }
}
        int preciototal = (numHamburguesaBasica * precioHamburguesaBasica)

package u1_entregable;

import java.util.Scanner;

public class Ej1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("Introduzca una altura");
            altura = scanner.nextInt();
        } while (altura < 3 || altura % 2 == 0);


        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < (altura * 3) - 2; j++) {
                if (j == 0 || j == 4 && i == (altura/2) - 1) {
                    System.out.println("*");
                }
            } else {
                System.out.println(" ");
                System.out.println();
            }

        }
    }
}

package u1_entregable;

import java.util.Scanner;

public class Ej4 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int num;
        int numeroultimos = 0;
        int cociente = num;
        int resto = 0;
        int contador = 0;


        do {
            System.out.println("Introduzca un numero de 6 cifras");
            num = scanner.nextInt();
        } while (num <= 100000 || num > 999999);

        for (int i = 0; cociente > 1000; i++) {
            resto = cociente % 10;
            cociente = cociente / 10;
            numeroultimo = (int) (numeroultimo + resto + Math.pow(10, contador));
            contador++;
        }
        int numeroprimero = (num - numeroultimos) / 1000;
    }

    int contadordivisible = 0;

    for(i =1; 1<=numeroprimero;i++);
        if(numeroprimero%i ==0)

    {
        contadordivisible++;

        if (contadordivisible == 2) {
            System.out.println(numeroprimero + "Es un numero primo");
        } else {
            System.out.println(numeroprimero + "no es un numero primo");
        }
    }
}
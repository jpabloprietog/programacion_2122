package u1_entregable;

import java.util.Scanner;

public class Ej2 {

    public static void main(String[] args) {

        long cociente = 3456759;
        int a_saltar = 1;

        do {
            if (a_saltar == 0);
            a_saltar = 1;
        } else {
            a_saltar--;
        }
        cociente = cociente / 10;
    } while(cociente != 0);
}
}

